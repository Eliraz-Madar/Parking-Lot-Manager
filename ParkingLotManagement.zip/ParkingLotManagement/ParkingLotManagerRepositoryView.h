#pragma once
#include "General.h"
#include "ParkingLotManager.h"

bool loadParkingLotManagerFromRepositoryUI(ParkingLotManager* parkingLotManager);
bool saveParkingLotManagerToRepositoryUI(const ParkingLotManager* parkingLotManager);
