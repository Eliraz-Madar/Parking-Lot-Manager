#pragma once
#include "DateTime.h"

DateTime createDateTimeUI();

void displayDateTime(const DateTime* dt);
