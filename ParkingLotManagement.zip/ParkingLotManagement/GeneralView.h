#pragma once
#include "General.h"

bool getBooleanValueUI(const char* message);

void clearInputBuffer();
