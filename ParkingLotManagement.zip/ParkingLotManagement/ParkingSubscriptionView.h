#pragma once
#include "General.h"
#include "ParkingSubscription.h"

ParkingSubscription createParkingSubscriptionUI();

void displayParkingSubscription(const ParkingSubscription* parkingSubscription);
